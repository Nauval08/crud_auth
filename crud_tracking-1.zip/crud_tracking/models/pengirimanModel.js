const db = require('../config/db');

const Pengiriman = {
    getAll: (callback) => {
        db.query('SELECT id, nama_penerima, alamat, status FROM pengiriman', callback);
    },

    getById: (id, callback) => {
        db.query('SELECT id, nama_penerima, alamat, status FROM pengiriman WHERE id = ?', [id], callback);
    },

    create: (data, callback) => {
        const { nama_penerima, alamat, status } = data;
        db.query('INSERT INTO pengiriman (nama_penerima, alamat, status) VALUES (?, ?, ?)', [nama_penerima, alamat, status], callback);
    },

    update: (id, data, callback) => {
        const { nama_penerima, alamat, status } = data;
        db.query('UPDATE pengiriman SET nama_penerima = ?, alamat = ?, status = ? WHERE id = ?', [nama_penerima, alamat, status, id], callback);
    },

    delete: (id, callback) => {
        db.query('DELETE FROM pengiriman WHERE id = ?', [id], callback);
    }
};

module.exports = Pengiriman;
