// controllers/pengirimanController.js
const Pengiriman = require('../models/pengirimanModel');

exports.getAll = (req, res) => {
    Pengiriman.getAll((err, result) => {
        if (err) return res.status(500).json({ message: 'Terjadi kesalahan pada server' });
        res.json(result);
    });
};

exports.getById = (req, res) => {
    Pengiriman.getById(req.params.id, (err, result) => {
        if (err) return res.status(500).json({ message: 'Terjadi kesalahan pada server' });
        if (!result.length) return res.status(404).json({ message: "Data tidak ditemukan" });
        res.json(result[0]);
    });
};

exports.create = (req, res) => {
    const { nama_penerima, alamat, status } = req.body;
    if (!nama_penerima || !alamat || !status) {
        return res.status(400).json({ message: "Semua field harus diisi" });
    }
    Pengiriman.create(req.body, (err, result) => {
        if (err) return res.status(500).json({ message: 'Gagal menambahkan data' });
        res.status(201).json({ id: result.insertId, ...req.body });
    });
};

exports.update = (req, res) => {
    const { nama_penerima, alamat, status } = req.body;
    if (!nama_penerima || !alamat || !status) {
        return res.status(400).json({ message: "Semua field harus diisi" });
    }
    Pengiriman.update(req.params.id, req.body, (err, result) => {
        if (err) return res.status(500).json({ message: 'Gagal mengupdate data' });
        if (result.affectedRows === 0) return res.status(404).json({ message: "Data tidak ditemukan" });
        res.json({ message: "Data berhasil diupdate" });
    });
};

exports.delete = (req, res) => {
    Pengiriman.delete(req.params.id, (err, result) => {
        if (err) return res.status(500).json({ message: 'Gagal menghapus data' });
        if (result.affectedRows === 0) return res.status(404).json({ message: "Data tidak ditemukan" });
        res.json({ message: "Data berhasil dihapus" });
    });
};
