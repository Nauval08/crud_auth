// routes/pengirimanRoutes.js
const express = require('express');
const router = express.Router();
const pengirimanController = require('../controllers/pengirimanController');
const authMiddleware = require('../middleware/authMiddleware');

// Semua route dilindungi oleh JWT
router.get('/', authMiddleware, pengirimanController.getAll);
router.get('/:id', authMiddleware, pengirimanController.getById);
router.post('/', authMiddleware, pengirimanController.create);
router.put('/:id', authMiddleware, pengirimanController.update);
router.delete('/:id', authMiddleware, pengirimanController.delete);

module.exports = router;